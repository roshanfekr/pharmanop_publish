
namespace NopTop.Plugin.Payments.Zarinpal.Models
{
    public class RestVerifyModel
    {
        public int Status { get; set; }
        public string RefID { get; set; }
    }
}