
namespace NopTop.Plugin.Payments.Zarinpal.Models
{
   public class RestRequestModel
    {
        public int Status { get; set; }
        public string Authority { get; set; }
    }
}