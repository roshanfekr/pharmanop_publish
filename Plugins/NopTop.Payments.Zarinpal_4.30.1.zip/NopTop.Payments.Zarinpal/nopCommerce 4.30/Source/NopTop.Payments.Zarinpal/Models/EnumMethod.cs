namespace NopTop.Plugin.Payments.Zarinpal.Models
{

    public enum EnumMethod
    {
        SOAP = 0,
        REST = 1,
    }
}